Changelog
=========

#### 1.1.1 - September 22, 2020
* Fix error register script bootstrap select 

#### 1.1.0 - September 18, 2020
* Update Smart Framework version 2.0

#### 1.0.9 - July 08, 2020
* Add filter option name
* Fix footer fixed 

#### 1.0.8 - March 28, 2020
* Fix get body class off header vertical 

#### 1.0.0 - February 25, 2017
* Inital Version