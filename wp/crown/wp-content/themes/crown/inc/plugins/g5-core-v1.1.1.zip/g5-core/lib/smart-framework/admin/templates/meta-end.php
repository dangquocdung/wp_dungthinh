			</div><!-- /.gsf-meta-box-fields -->
			<div class="gsf-meta-box-wrap-loading">
				<div class="loader"></div>
			</div>
		</div><!-- /.gsf-meta-box-fields-wrapper -->
	</div><!-- /.gsf-meta-box-wrap-inner -->
</div><!-- /.gsf-meta-box-wrap -->