Changelog
=========

#### 1.0.8 - July 28, 2020
* Update param image hover in shortcode image box

#### 1.0.7 - June 30, 2020
* Fix custom color hover

#### 1.0.6 - April 03, 2020
* Fix edit page with WPBakery Page Builder in backend

#### 1.0.5 - March 28, 2020
* Fix edit page with WPBakery Page Builder in frontend
* Fix error enqueue shortcode assets with php 7.4 

#### 1.0.0 - February 25, 2017
* Inital Version