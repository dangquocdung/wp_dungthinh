<?php
/**
 * Element class
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_G5Element_Breadcrumbs extends G5Element_ShortCode_Base {
}
