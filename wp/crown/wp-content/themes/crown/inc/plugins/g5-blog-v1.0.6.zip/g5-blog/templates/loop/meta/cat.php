<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
?>
<i class="far fa-folder-open"></i> <?php echo get_the_category_list(' / '); ?>

