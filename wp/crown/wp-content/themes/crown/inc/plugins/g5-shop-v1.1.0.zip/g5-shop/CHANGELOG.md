Changelog
=========

#### 1.1.0- September 22, 2020
* Update display wishlist button in single product


#### 1.0.9- September 18, 2020
* Update template cross-sells version 4.4.0

#### 1.0.8 - July 29, 2020
* Fix register meta for attributes product

#### 1.0.7 - May 04, 2020
* Fix save attributes in product page
* Compatible with woocommerce 4.0.1

#### 1.0.6 - April 01, 2020
* Fix warning variable image_size in template  woocommerce/content-product_cat.php

#### 1.0.0 - February 25, 2017
* Inital Version