Change Log :

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.1 ==
- [BUG] Fix class not found issue

== 6.0.0 ==
- First Release
