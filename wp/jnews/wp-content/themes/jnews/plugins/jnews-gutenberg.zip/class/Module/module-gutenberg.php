<?php

class JNews_Block_1 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_2 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_3 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_4 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_5 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_6 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_7 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_8 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_9 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_10 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_11 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_12 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_13 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_14 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_15 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_16 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_17 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_18 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_19 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_20 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_21 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_22 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_23 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_24 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_25 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_26 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_27 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_28 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_29 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_30 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_31 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_32 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_33 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_34 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_35 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_36 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_37 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_38 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Block_39 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_1 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_2 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_3 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_4 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_5 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_6 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_7 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_8 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Slider_9 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_1 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_2 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_3 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_4 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_5 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_6 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_7 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_8 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_9 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_10 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_11 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_12 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_13 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_14 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Hero_Skew extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Element_Ads extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Element_Newsticker extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Element_Header extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Element_Videoplaylist extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Element_Embedplaylist extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Element_Blocklink extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Carousel_1 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Carousel_2 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}

class JNews_Carousel_3 extends \JNEWS_GUTENBERG\Module\ModuleAbstract {}
