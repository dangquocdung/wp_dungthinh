<?php

return [
	[
		'name'   => 'JNews_Footer_Instagram',
		'type'   => 'carousel',
		'image'  => '',
		'widget' => true,
		'view'   => '/class/module/element/class-jnews-instagram-module-view.php',
		'option' => '/class/module/element/class-jnews-instagram-module-option.php',
	],
];
