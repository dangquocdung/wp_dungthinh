<?php
/**
 * BuddyPress - Custom Home
 */
?>
<div id="member-home-widgets" class="bp-home-member-area" role="complementary">
	<?php dynamic_sidebar( 'jnews-bp-home' ); ?>
</div><!-- .bp-sidebar.bp-widget-area -->
