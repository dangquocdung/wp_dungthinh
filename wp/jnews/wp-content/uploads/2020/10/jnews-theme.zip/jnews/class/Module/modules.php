<?php

return array(
    array(
        'name'      => 'JNews_Block_1',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_2',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_3',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_4',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_5',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_6',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_7',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_8',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_9',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_10',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_11',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_12',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_13',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_14',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_15',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_16',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_17',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_18',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_19',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_20',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_21',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_22',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_23',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_24',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_25',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_26',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_27',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_28',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_29',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Block_30',
        'type'      => 'block',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Block_31',
        'type'      => 'block',
        'widget'    => true
    ),
	array(
		'name'      => 'JNews_Block_32',
		'type'      => 'block',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Block_33',
		'type'      => 'block',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Block_34',
		'type'      => 'block',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Block_35',
		'type'      => 'block',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Block_36',
		'type'      => 'block',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Block_37',
		'type'      => 'block',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Block_38',
		'type'      => 'block',
		'widget'    => false
	),
    array(
        'name'      => 'JNews_Block_39',
        'type'      => 'block',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_1',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_2',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_3',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_4',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_5',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_6',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_7',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_8',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_9',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_10',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_11',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_12',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_13',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_14',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Hero_Skew',
        'type'      => 'hero',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Slider_Overlay',
        'type'      => 'slider_overlay',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Slider_1',
        'type'      => 'slider',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Slider_2',
        'type'      => 'slider',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Slider_3',
        'type'      => 'slider',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Slider_4',
        'type'      => 'slider',
        'widget'    => false
    ),
	array(
		'name'      => 'JNews_Slider_5',
		'type'      => 'slider',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Slider_6',
		'type'      => 'slider',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Slider_7',
		'type'      => 'slider',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Slider_8',
		'type'      => 'slider',
		'widget'    => false
	),
    array(
        'name'      => 'JNews_Slider_9',
        'type'      => 'slider',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Element_Ads',
        'type'      => 'ads',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Element_Newsticker',
        'type'      => 'newsticker',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Element_Header',
        'type'      => 'header',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Element_Videoplaylist',
        'type'      => 'video_playlist',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Element_Userlist',
        'type'      => 'userlist',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Element_Embedplaylist',
        'type'      => 'video_playlist',
        'widget'    => true
    ),
    array(
        'name'      => 'JNews_Element_Blocklink',
        'type'      => 'block_link',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Element_Splitnav',
        'type'      => 'split_navigation',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Element_Iconlink',
        'type'      => 'icon_link',
        'widget'    => false
    ),
	array(
		'name'      => 'JNews_Element_Socialiconwrapper',
		'type'      => 'social_icon_wrapper',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Element_Socialiconitem',
		'type'      => 'social_icon_item',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Element_Socialcounterwrapper',
		'type'      => 'social_counter_wrapper',
		'widget'    => false
	),
	array(
		'name'      => 'JNews_Element_Socialcounteritem',
		'type'      => 'social_counter_item',
		'widget'    => false
	),


    array(
        'name'      => 'JNews_Carousel_1',
        'type'      => 'carousel',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Carousel_2',
        'type'      => 'carousel',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Carousel_3',
        'type'      => 'carousel',
        'widget'    => false
    ),

    /** Footer */
    array(
        'name'      => 'JNews_Footer_Menu',
        'type'      => 'footer',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Footer_Social',
        'type'      => 'footer',
        'widget'    => false
    ),
	array(
		'name'      => 'JNews_Footer_Header',
		'type'      => 'footer',
		'widget'    => false
	),

    /** Single Post */
    array(
        'name'      => 'JNews_Post_Title',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Subtitle',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Breadcrumb',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Meta',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Feature',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Content',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Share',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Tag',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Author',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Sequence',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Comment',
        'type'      => 'post',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Post_Related',
        'type'      => 'post',
        'widget'    => false
    ),
	array(
		'name'      => 'JNews_Post_Source',
		'type'      => 'post',
		'widget'    => false
	),

    /** Widget */
    array(
        'name'      => 'JNews_Widget_About',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_Behance',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_FacebookPage',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_Flickr',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_GooglePlus',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_Instagram',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_Pinterest',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_Popular',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_RecentNews',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_TabPost',
        'type'      => 'widget',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Widget_Twitter',
        'type'      => 'widget',
        'widget'    => false
    ),

    /** Single Archive */
    array(
        'name'      => 'JNews_Archive_Title',
        'type'      => 'archive',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Archive_Desc',
        'type'      => 'archive',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Archive_Breadcrumb',
        'type'      => 'archive',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Archive_Hero',
        'type'      => 'archive',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Archive_Block',
        'type'      => 'archive',
        'widget'    => false
    ),
    array(
        'name'      => 'JNews_Archive_Pagination',
        'type'      => 'archive',
        'widget'    => false
    ),
);
