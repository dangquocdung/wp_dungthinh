<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Carousel;

Class Carousel_3_Option extends CarouselOptionAbstract
{
    public function get_module_name()
    {
        return esc_html__('JNews - Carousel 3', 'jnews');
    }
}