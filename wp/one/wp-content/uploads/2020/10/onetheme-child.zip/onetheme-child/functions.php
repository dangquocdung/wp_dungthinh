<?php

/* --------- Insert your customized functions on next rows --------- */


function onetheme_child_enqueue_styles() {

    $parent_style = 'onetheme-stylesheet';

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'onetheme-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style )
    );
}
add_action( 'wp_enqueue_scripts', 'onetheme_child_enqueue_styles' );


?>