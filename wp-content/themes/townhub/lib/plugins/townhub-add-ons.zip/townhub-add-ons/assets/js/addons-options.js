(function($){
	'use strict';
	$(function(){
		$('.use-select2').select2();
	})
})(jQuery);